# Gaming Shorts Automation (starter)

Starter project for 4 daily YouTube Shorts uploads as **Private**. It intentionally does **not** scrape/download arbitrary streamer videos. Add only clips you own or have permission/licence to reuse, and record that permission in `assets/clips.json`.

## What it does
- Scheduled at 08:00, 12:00, 16:00, 20:00 WIB (GitHub cron uses UTC).
- Builds one vertical video per run, up to 90 seconds, from five approved moments.
- Displays rank #5 through #1 and source/streamer text on each clip; no voice narration.
- Uploads as Private using YouTube Data API OAuth.
- Fails closed: if fewer than five eligible, approved clips exist, no video is built/uploaded.
- Avoids reusing the same clip by recording IDs in `state/used.json` (persisted as a workflow artifact is not a robust long-term database; see notes below).

## Important limitations
1. **This is not an automatic trend/clip discovery engine yet.** Public APIs do not grant rights to reuse stream footage. Discover candidate moments separately, then add a local video file and a permission record to the manifest. This prevents accidental unauthorized reposting.
2. GitHub-hosted runners are ephemeral. The workflow checks out the repository, so your approved clip files and manifest must be in the repository. Keep clips small and consider storage/bandwidth. Do not commit large copyrighted videos.
3. A free GitHub Actions quota is not an unconditional unlimited guarantee. GitHub Free currently includes 2,000 minutes/month for standard runners on private repositories; standard runners on public repositories are free. Billing/limits can change. See https://docs.github.com/en/billing/concepts/product-billing/github-actions
4. GitHub scheduled workflows can be delayed and may not run at exact minute. Do not use this for time-critical scheduling.
5. Upload API quota and OAuth verification/audit restrictions may apply. See https://developers.google.com/youtube/v3/docs/videos/insert
6. Source attribution does not itself grant permission. Confirm commercial/derivative-use rights and follow the creator's licence/terms.

## Repository layout
```text
.github/workflows/daily-shorts.yml
assets/clips.json
assets/clips/              # approved local clip files
src/authorize_youtube.py   # run locally once to obtain token.json
src/build_and_upload.py
requirements.txt
```

## 1) Add approved clips
Place up to twenty permitted video files in `assets/clips/` (five distinct clips for each of four daily Shorts) and edit `assets/clips.json`. Each entry must include:
- `id`: unique stable ID
- `file`: path relative to repo root
- `streamer`: streamer name
- `source_url`: URL of original clip/source
- `permission_evidence`: short note such as `creator email permission dated YYYY-MM-DD`, `CC BY 4.0 URL`, or `owned footage`
- `approved`: must be `true`
- `start_seconds`: start time within the local file
- `duration_seconds`: 8–15 seconds recommended
- `moment_label`: brief non-misleading description

Only include clips whose permission explicitly covers the intended reuse. For CC licences, comply with attribution and any other licence requirements.

## 2) Set up YouTube OAuth
1. Open https://console.cloud.google.com/ and create a project.
2. Enable **YouTube Data API v3**.
3. Configure OAuth consent screen. For personal testing, use the applicable user type and add your account as a test user if required.
4. Create OAuth Client ID credentials of type **Desktop app** and download the client JSON as `client_secret.json` into the project root (do not commit it).
5. Locally install dependencies: `python -m pip install -r requirements.txt`
6. Run `python src/authorize_youtube.py`. Sign in to the Google account that owns the target channel and grant `youtube.upload` permission. This creates `token.json`.
7. Encode the token JSON as Base64:
   - Linux/macOS: `base64 -w 0 token.json` (on macOS use `base64 < token.json | tr -d '\\n'`)
   - PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("token.json"))`
8. In GitHub repository → Settings → Secrets and variables → Actions → New repository secret:
   - `YOUTUBE_TOKEN_JSON_B64` = the Base64 output of `token.json`
9. Do not add `token.json` or `client_secret.json` to Git. Revoke the token if exposed.

OAuth refresh tokens may expire or be revoked; if upload starts failing with auth errors, repeat authorization and update the secret.

## 3) Add GitHub Actions
Push this project to a GitHub repository. For a private repo, monitor your included Actions minutes. In Settings → Actions, ensure Actions are allowed.

The workflow uses these cron expressions (UTC):
- `0 1 * * *` = 08:00 WIB
- `0 5 * * *` = 12:00 WIB
- `0 9 * * *` = 16:00 WIB
- `0 13 * * *` = 20:00 WIB

GitHub cron is UTC; Jakarta is UTC+7.

## 4) Run a manual test
Repository → Actions → `Build and upload approved Gaming Short` → Run workflow.
The job will stop without upload if fewer than five valid approved clips exist for that time slot. To create four different Shorts per day, provide 20 approved clips (5 per slot) in manifest order.

## Cost-zero guardrails
- Use GitHub-hosted standard Ubuntu runner only.
- Do not enable paid larger runners or external paid APIs.
- Keep clip durations/files small; build only one video per run.
- No paid AI APIs are required; ranking is a manually curated order in the manifest. The first five eligible entries feed the 08:00 slot, the next five the 12:00 slot, then 16:00 and 20:00.
- If no eligible clips, invalid files, FFmpeg errors, or upload errors occur, the run fails and logs the reason. It does not publish publicly.
- GitHub Actions usage and Google API quota/eligibility can change; check current terms and billing settings.

## Production hardening to add later
For robust deduplication, move the used-clip ledger to a small persistent store or commit state with a narrowly scoped GitHub App/token. The starter does not automatically push state changes back to the repo.
